package com.isrg.second;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * コードブレイカー：数当てゲーム
 *
 */

public class CodeBreaker2 {
	
	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		
		GameComponent gc = new GameComponent();
		
		/**
		 *  try_count:挑戦回数
		 */
		int try_count = 0;
		
		// タイトルと説明の表示
		BufferedReader br = 
				new BufferedReader(new InputStreamReader(System.in));
		System.out.println(gc.getTitle());
		System.out.println(gc.getArticleOfRule());

		// 正答をランダムに生成する
		gc.makeAnswers();
		
		// ゲーム部
		while(true) {
			try_count++;
			System.out.println("～～～ " + try_count + "回目 ～～～");
			for(int i = 0; i < gc.getNumberOfAnswers(); i++) {
				System.out.print((i + 1) + "個目：");
				
				try {
					gc.inputAnswer(i, br.readLine());
				} catch (InputErrorException e) {
					System.out.println(e.getMessage());
					i--;
				} catch (IOException e) {
					System.out.println("もう一度入力してください");
					i--;
				}
			}

		// 回答チェック
		boolean end_flag = gc.judge();	
			
		// 終了かどうかを判定、ヒット数が3になったら終了
		System.out.println("ヒット"+ gc.getHit() +" ブロー"+ gc.getBlow());
			if(end_flag) {
				System.out.println("!!!Bingo!!!");
				break;
			}else{
				System.out.println();
			}
			}
		}
	}