package com.isrg.second;

public class InputErrorException extends Exception {

	private static final long serialVersionUID = 1L;

	public InputErrorException(String str) {
		super(str);
	}
}
