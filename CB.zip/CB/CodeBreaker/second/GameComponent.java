package com.isrg.second;

/**
 * com.isrg.first.CodeBreaker1クラスの各要素を
 * メソッド化
 *
 * @author isrg
 */

public class GameComponent {
	/**	ゲームのタイトル */
	private String title = "### CodeBreaker ###";
	
	/**	ゲームのルール説明 */
	private String articleOfRule = "隠された3つの数字を当てる、数当てゲームです。\n"
			+ "数字は1～6の間で入力します。\n"
			+ "3つの数字に同じ値はなく、重複しません。\n"
			+ "「ヒット」は数字と位置の両方が合っていることを意味し、\n"
			+ "「ブロー」は数字が正答に含まれるが、\n"
			+ "位置が異なることを意味します。\n"
			+ "全部当てると(3か所ともHitになると)\n"
			+ "ゲームクリアとなります。\n";
	
	/**	正答の桁数、今後の拡張に対応 */
	private int numberOfAnswers = 3;
	
	/**	乱数幅保持用の定数 */
	private int widthOfRandom = 6;
	
	/**	正答を格納する配列 */
	private int answer[];
	
	/**	入力文字を格納する配列 */
	private int input[];
	
	/**	挑戦回数 */
	private int try_count;
	
	/**	ヒット数 */
	private int hit;
	
	/**	ブロー数 */
	private int blow;
	
	/**	デフォルトコンストラクタ */
	public GameComponent(){
		answer = new int[numberOfAnswers];
		input  = new int[numberOfAnswers]; 
		makeAnswers();
	}
	
	/**	コンストラクタをオーバーロード：正答の桁数を変更して初期化 */
	public GameComponent(int numberOfAnswers){
		this.numberOfAnswers = numberOfAnswers;
		answer = new int[numberOfAnswers];
		input  = new int[numberOfAnswers];
		makeAnswers();
	}
	
	/**
	 * 正答を作成する：
	 * 正答の桁数変更を考慮し、numberOfAnswersと照合する
	 */
	public void makeAnswers() {
		if(answer.length != numberOfAnswers) {
			answer = new int[numberOfAnswers];
			input  = new int[numberOfAnswers];
		}
		for (int i = 0; i < answer.length; i++) {
			// 
			boolean flag = false;
			answer[i] = (int)(Math.random() * 6 + 1);
			
            do {
                
            	flag = false;
                
                for (int j = i - 1; j >= 0; j--) {
                	if (answer[i] == answer[j]) {
                		flag = true;
                		answer[i] = (int) (Math.random() * 6 + 1);
                    }
                }

            } while (flag == true);
		}
	}
	
	/**
	 * indexで要素を指定して答えを入力する、indexは0から始まる
	 * 
	 * @param index
	 * @param answer
	 * @throws Exception
	 */
	public void inputAnswer(int index, int answer) 
					throws InputErrorException {
		if(index > -1 && index < numberOfAnswers) {
			if(answer > 0 && answer <= widthOfRandom) {
				input[index] = answer;
			} else {
				throw new InputErrorException("入力された値が範囲外です");
			} 
			} else {
				throw new InputErrorException("入力する箇所が異なります");
			}
		}
	public void inputAnswer(int index, String string) throws InputErrorException{
		int answer;
		
		try {
			answer = Integer.parseInt(string);
		} catch (NumberFormatException e){
			throw new InputErrorException("入力された値が範囲外です");
		}
		inputAnswer(index, answer);
	}
	
	public boolean judge() {
		// 回答を判定する
		hit = 0;
		blow = 0;
		
		for(int i = 0; i < answer.length; i++) {
			for(int j = 0; j < answer.length; j++) {
				
				// hit判定
				if(i == j && input[i] == answer[j]) {
					hit += 1;
				}else if 
				// blow判定
				(input[i] == answer[j]) {
					blow += 1;
				}
			}
		}
		return (hit == numberOfAnswers);
	}
	
	public int getNumberOfAnswers() {
		return numberOfAnswers;
	}
	
	public int getWidthOfRandom() {
		return widthOfRandom;
	}
	
	public int[] getAnswer() {
		return answer;
	}
	
	public int getHit() {
		return hit;
	}
	
	public int getBlow() {
		return blow;
	}
	
	public int getNumberOfTry() {
		return try_count;
	}
	
	public int[] getInput() {
		return input;
	}
	
	public void setInput(int[] input) throws InputErrorException {
		for (int i = 0; i < input.length; i++) {
			inputAnswer(i, input[i]);
		}
	}
	
	public String getArticleOfRule() {
		return articleOfRule;
	}
	
	public void setArticleOfRule(String articleOfRule) {
		this.articleOfRule = articleOfRule;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
}
