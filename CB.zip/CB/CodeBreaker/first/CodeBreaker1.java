package com.isrg.first;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * コードブレイカー：数当てゲーム
 *
 */

public class CodeBreaker1 {
	
	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		
		String title = "～～～ CodeBreaker ～～～\n";
		String article_of_rule = "3つの数字を使った数当てゲームです。\n"
				+ "数字は1～6の範囲で入力し、重複がないようにします。\n"
				+ "「ヒット」は数字と位置の両方が合っていることを意味し、\n"
				+ "「ブロー」は数字が正答に含まれるが、"
				+ "位置が異なることを意味します。\n";
		
		int answer[] = new int[3];
		int input[]  = new int[3];
		
		/**
		 *  hit:ヒットの数
		 *  blow:ブローの数
		 *  try_count:挑戦回数
		 */
		
		int hit = 0, blow = 0, try_count = 0;
		
		// タイトルと説明の表示
		System.out.println(title);
		System.out.println(article_of_rule);
		
		// 3桁の乱数を生成
		for (int i = 0; i < answer.length; i++) {
			boolean flag = false;
			answer[i] = (int)(Math.random() * 6 + 1);
			
            do {
                
            	flag = false;
                
                for (int j = i - 1; j >= 0; j--) {
                    if (answer[i] == answer[j]) {
                        flag = true;
                        answer[i] = (int) (Math.random() * 6 + 1);
                    }
                }

            } while (flag == true);
		}
		
		// ゲーム部
		BufferedReader br = 
		new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			try_count++;
			System.out.println("～～～ " + try_count + "回目 ～～～");
			for(int i = 0; i < answer.length; i++) {
				System.out.println((i + 1) + "個目：");
				
				try {
					input[i] = Integer.parseInt(br.readLine());
				} catch (NumberFormatException e) {
					System.out.println("数字を入力してください");
					i--;
				} catch (IOException e) {
					System.out.println("もう一度入力してください");
					i--;
				}
			}

		// 回答チェック
		hit = 0;
		blow = 0;
		
		for(int i = 0; i < answer.length; i++) {
			for(int j = 0; j < answer.length; j++) {
					
			// hit判定
			if(i == j && input[i] == answer[j]) {
				hit += 1;
			}else if 
			// blow判定
			(input[i] == answer[j]) {
				blow += 1;
				}
			}
		}
		// 終了判定、ヒット数が3になったら終了
		System.out.println("ヒット"+ hit +" ブロー"+ blow);
			if(hit == 3) {
				System.out.println("Bingo!");
				break;
			}else{
				System.out.println();
			}
			}
		}
	}