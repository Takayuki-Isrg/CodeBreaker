package com.isrg.third;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

import com.isrg.second.GameComponent;
import com.isrg.second.InputErrorException;

public class CodeBreakerThird extends JFrame implements ActionListener {
	
	private JPanel panel, centorPanel, southPanel;
	
	private JScrollPane sc;
	
	private DefaultTableModel dtm;
	
	private JTable resultTable;
	
	private JComboBox[] inputBox = new JComboBox[3];
	
	private String [] selector = {"1", "2", "3", "4", "5", "6"};
	
	private JButton judge;
	
	private GameComponent gc = new GameComponent();
	
	public CodeBreakerThird() {

	// GUI、Panelの初期化
	panel = new JPanel(new BorderLayout());
	centorPanel = new JPanel();
	southPanel = new JPanel();
	
	// テーブル部：結果表示、ここではJTableを使用する
	dtm = new DefaultTableModel();
	dtm.addColumn("1");
	dtm.addColumn("2");
	dtm.addColumn("3");
	dtm.addColumn("HIT");
	dtm.addColumn("BLOW");
	
	resultTable = new JTable(dtm);
	resultTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
	sc = new JScrollPane(resultTable, 
			ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	centorPanel.add(sc);

	// 入力部分を作成
	for(int i = 0; i < 3; i++) {
		inputBox[i] = new JComboBox(selector);
		inputBox[i].setActionCommand("" + i);
		inputBox[i].addActionListener(this);
		southPanel.add(inputBox[i]);
	}
	// 判定ボタンの設置
	judge = new JButton("判定");
	judge.setActionCommand("JUDGE");
	judge.addActionListener(this);
	southPanel.add(judge);
	
	// テーブル部、入力部のセット
	panel.add(centorPanel, BorderLayout.CENTER);
	panel.add(southPanel, BorderLayout.SOUTH);
	this.getContentPane().add(panel);
	
	// 表示
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setBounds(100, 100, 400, 500);
	this.pack();
	this.setTitle(gc.getTitle());
	this.setVisible(true);
	
	//ルールの表示
    JOptionPane.showMessageDialog(this, 
	gc.getArticleOfRule(), gc.getTitle(), JOptionPane.INFORMATION_MESSAGE);
    
    // GameComponentの初期化
    try {
    	gc.setInput(new int[] {1, 1, 1});
    } catch (InputErrorException e){
    	JOptionPane.showMessageDialog(this, gc.getArticleOfRule(), gc.getTitle(), 
    			JOptionPane.ERROR_MESSAGE);
    }
}
	
    /**
     * @see java.awt.event.ActionListener#actionPerformed
     *
     */
    public void actionPerformed(ActionEvent arg0) {
    	if (arg0.getActionCommand().equalsIgnoreCase("judge")) {
    	boolean judge = gc.judge();
    
    // コンソールへの確認用データの表示
    int ans[] = gc.getAnswer();
    System.out.println("答え");
    
    for(int i = 0; i < ans.length; i++) {
    	System.out.print(ans[i]);
    }
    System.out.println();
    System.out.println("入力");
    int input[] = gc.getInput();
    
    for(int i = 0; i < input.length; i++) {
    	System.out.print(input[i]);
    }
    System.out.println();
    System.out.println("Hit" + gc.getHit() + "Blow" + gc.getBlow());
    
    // 結果をresultTableへ出力
    Object row[] = new Object[5];
    
    for(int i = 0; i < 3; i++) {
    	row[i] = Integer.valueOf(input[i]);
    }
    
    row[3] = Integer.valueOf(gc.getHit());
    row[4] = Integer.valueOf(gc.getBlow());
    dtm.addRow(row);
    
    // 全問正解時の処理
    if(judge) {
    	int res = JOptionPane.showConfirmDialog(this, "もう一度プレイしますか？", 
    			  "Bingo!", JOptionPane.YES_NO_OPTION);
    if(res == JOptionPane.YES_OPTION) {
    // resultTableの初期化
    	int count = dtm.getRowCount();
    	
    	for(int i = 0; i < count; i++) {
    		dtm.removeRow(0);
    	}
    // GameComponentの初期化
    gc.makeAnswers();
    
    	try {
			gc.setInput(new int[] {1, 1, 1});
		} catch (InputErrorException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), 
					gc.getTitle(), JOptionPane.ERROR_MESSAGE);
		}
    	gc.judge();
    	
    	// GUIの初期化
    	for (int i = 0; i < inputBox.length; i++) {
			inputBox[i].setSelectedIndex(0);
		}
    } else {
    	System.exit(0);
    
    	}
    }
    
    } else { // judge以外のため、入力部分の処理
    	// 入力部分の特定
    	int input = Integer.parseInt(arg0.getActionCommand());
    	
    	try {
    		gc.inputAnswer(input, (String) inputBox[input]
    		.getSelectedItem());
    	
    	} catch (InputErrorException e) {
    		JOptionPane.showMessageDialog(this, e.getMessage(), 
    		gc.getTitle(), JOptionPane.ERROR_MESSAGE);
    	}
	}
}
	
	/**
	 * mainメソッド：ここではGUIの起動のみ行う
	 *
	 */
	public static void main(String[] args) {
		new CodeBreakerThird();
	}
}